
<?php
ob_start();
?>


    <div class="container mx-auto p-4">
        <h1 class="text-2xl font-semibold mb-4">Route Management</h1>
        <a href="index.php?action=add_route"><button><i class='fa fa-plus'></i> Add Route</button></a>

        <table class="min-w-full bg-white border border-gray-300">
            <thead>
                <tr class="items-center">
                    <th class="py-2 px-4 border-b">idRout</th>
                    <th class="py-2 px-4 border-b">ville_departID</th>
                    <th class="py-2 px-4 border-b">ville_arriveeID</th>
                    <th class="py-2 px-4 border-b">duree</th>
                    <th class="py-2 px-4 border-b">distance</th>
                    <th class="py-2 px-4 border-b">Actions</th>
                </tr>
            </thead>
            <tbody class="">
                <?php foreach ($routesDATA as $route) : ?>
                    <tr>
                        <td class="py-2 px-4 border-b"><?= $route->getIdRoute(); ?></td>
                        <td class="py-2 px-4 border-b"><?= $route->getVille_departID(); ?></td>
                        <td class="py-2 px-4 border-b"><?= $route->getVille_arriveeID(); ?></td>
                        <td class="py-2 px-4 border-b"><?= $route->getDuree(); ?></td>
                        <td class="py-2 px-4 border-b"><?= $route->getDistance(); ?></td>
                        <td class="py-2 px-4 border-b">
                            <ul class='action-list'>
                                <li><a href='index.php?action=add_route&id=<?= $route->getIdRoute() ?>' data-tip='add'><i class='fa fa-plus'></i></a></li>
                                <li><a href='index.php?action=updateroute&id=<?= $route->getIdroute() ?>' data-tip='edit'><i class='fa fa-edit'></i></a></li>
                                <li><a href='index.php?action=delete_route&id=<?= $route->getIdroute() ?>' data-tip='delete'><i class='fa fa-trash'></i></a></li>
                            </ul>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</body>
</html>
<?php
$content = ob_get_clean();
include_once 'layout.php';
?>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
