<?php

define('DB_HOST', 'localhost');

define('DB_NAME', 'easytravel');

define('DB_USER', 'root');

define('DB_PASS', '');

?>